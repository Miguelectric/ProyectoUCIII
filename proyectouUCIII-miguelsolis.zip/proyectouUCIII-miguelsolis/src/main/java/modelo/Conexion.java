package modelo;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    private static final String URL = "jdbc:sqlserver://localhost:8081;databaseName=ProyectoUCIII;encrypt=true;trustServerCertificate=true;";
    private static final String USER = "proyectouciii";
    private static final String PASSWORD = "12345";

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a SQL Server");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }
}
