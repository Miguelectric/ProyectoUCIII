package filtros;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebFilter("/*")
public class FiltroLogin implements Filter {
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
        throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession sesion = req.getSession(false);

        boolean logeado = (sesion != null && sesion.getAttribute("usuario") != null);
        String path = req.getRequestURI();

        if (logeado || path.contains("login.jsp") || path.contains("RegistroServlet") || path.contains("registro.jsp") || path.endsWith("css") || path.contains("index.jsp")) {
            chain.doFilter(request, response);
        } else {
            res.sendRedirect(req.getContextPath() + "/login.jsp");
        }
    }
}
